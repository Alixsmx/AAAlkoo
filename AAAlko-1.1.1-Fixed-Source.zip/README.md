# AAAlko — Android File Manager

**Source version: 1.1.1**

AAAlko is an Android file-management app built with **Kotlin, Jetpack Compose and Material 3**. It uses an AMOLED-dark interface, translucent Liquid Glass-inspired surfaces, animated screen transitions and a six-item bottom navigation. Polish is the default language; English can be selected in Settings.

## Build corrections in 1.1.1

- Added the missing `androidx.activity.compose.setContent` import used by `FragmentActivity`.
- Replaced the unavailable `Icons.Rounded.Encrypted` reference with the supported lock icon.
- Corrected Android Back handling so nested folders and the trash are exited before returning to Home.
- Changed vault export to decrypt into the app-private cache first; the selected destination is written only after AES-GCM stream authentication completes.

## Implemented modules

- **File manager:** browse a user-selected SAF location, navigate folders, search current-folder entries, sort by name/date/size/type, create files and folders, rename, view details, mark favourites, multi-select, copy/cut/paste files and directories recursively, and move deleted items to an in-location trash folder. Items in the trash can be restored or permanently deleted.
- **Gallery:** create persistent album folders under `AAAlko Albums`, import image files by copying them into an album, display image thumbnails and open photos with an installed Android app.
- **Text/code editor:** open text-like files from the file manager, Android's document picker or another app through an `ACTION_VIEW` intent; edit, overwrite where the provider allows it, or use Save as.
- **Encrypted vault:** store imported files encrypted with AES-256-GCM using an Android Keystore key; PINs are salted and derived with PBKDF2-HMAC-SHA256 rather than stored as plain text. Export decrypts the file through Android's document picker. Biometric/device-credential prompt is available as an additional app-unlock option.
- **Settings:** switch Polish/English and select the SAF storage location.

## Android storage model

AAAlko does not request unrestricted access to all shared storage. The user explicitly chooses a folder through Android's Storage Access Framework, and file operations remain within the granted tree. Gallery imports are persistent copies in that chosen location. The encrypted vault lives in the app's private storage area.

## Security notes

Vault file contents are encrypted with AES-256-GCM. The encryption key is managed by Android Keystore. The biometric prompt unlocks the vault screen using the device's biometric/device credential; the AES key itself is not configured as a per-use biometric-authenticated key. Clearing app data or losing the device's Keystore state can make vault data unrecoverable. Keep an independent backup of originals before importing them into the vault.

The vault is an application-level encrypted store, not a substitute for a full security audit. The app should be tested on the target Android versions and devices before storing sensitive data.

## Known limitations

- Liquid Glass is implemented as a Compose visual treatment (translucent fills, gradients, borders and animation), not native refractive glass rendering.
- Text editor is a basic monospace editor; it does not provide language-aware syntax highlighting, code execution or advanced IDE features.
- Search is scoped to the currently opened folder; it is not a recursive whole-device index.
- Operations depend on capabilities of the selected document provider. Some providers may reject rename, overwrite, delete, or recursive operations.
- Media import handles image files; it does not index every item in the device's MediaStore library automatically.
- No release APK is included. The source still needs a successful Android build and real-device QA before a production release.

## Build locally

Requirements: Android Studio, JDK 17 and Android SDK Platform 35.

Open the repository root in Android Studio and allow Gradle sync. Then choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**, or run:

```bash
./gradlew assembleDebug
```

The debug APK is generated at:

```text
app/build/outputs/apk/debug/app-debug.apk
```

## GitHub Actions (add manually)

The project ZIP intentionally excludes the workflow. Create this file yourself:

```text
.github/workflows/build-apk.yml
```

Paste the workflow YAML supplied separately. After committing it, open **Actions → Build AAAlko APK → Run workflow**. When the run succeeds, download the `AAAlko-debug-apk` artifact and extract `app-debug.apk`.

The workflow builds a **debug APK** for testing. A production release must be signed with a private release keystore. Never commit a keystore or passwords to GitHub; use GitHub Actions secrets for release signing.
