package pl.aaalko.app

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.togetherWith
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items as gridItems
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.documentfile.provider.DocumentFile
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.DecimalFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Bg = Color(0xFF05070A)
private val Panel = Color(0xFF111722)
private val Glass = Color(0x25FFFFFF)
private val GlassStroke = Color(0x38FFFFFF)
private val Accent = Color(0xFFB8DFFF)
private val Muted = Color(0xFF8D99A8)
private val Good = Color(0xFF75D7B0)

class MainActivity : FragmentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.TRANSPARENT
        window.navigationBarColor = android.graphics.Color.TRANSPARENT
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = (
            android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or
                android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
            )
        setContent { AAAlkoApp(initialUri = intent?.data, onBiometric = { success, failure -> authenticateBiometric(success, failure) }) }
    }

    private fun authenticateBiometric(onSuccess: () -> Unit, onFailure: (String) -> Unit) {
        val biometricOnly = BiometricManager.Authenticators.BIOMETRIC_STRONG
        val deviceCredential = BiometricManager.Authenticators.DEVICE_CREDENTIAL
        val supportsDeviceCredentialFallback = Build.VERSION.SDK_INT >= 30
        val authenticators = if (supportsDeviceCredentialFallback) biometricOnly or deviceCredential else biometricOnly
        val availability = BiometricManager.from(this).canAuthenticate(authenticators)
        if (availability != BiometricManager.BIOMETRIC_SUCCESS) {
            onFailure("Biometria lub blokada ekranu nie jest dostępna na tym urządzeniu.")
            return
        }
        val prompt = BiometricPrompt(this, ContextCompat.getMainExecutor(this), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { onSuccess() }
            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { onFailure(errString.toString()) }
        })
        val builder = BiometricPrompt.PromptInfo.Builder()
            .setTitle("AAAlko — sejf")
            .setSubtitle("Potwierdź tożsamość, aby otworzyć prywatne pliki")
            .setAllowedAuthenticators(authenticators)
        if (!supportsDeviceCredentialFallback) builder.setNegativeButtonText("Anuluj")
        prompt.authenticate(builder.build())
    }
}

private enum class AppTab(val pl: String, val en: String, val icon: ImageVector) {
    HOME("Start", "Home", Icons.Rounded.Home),
    FILES("Pliki", "Files", Icons.Rounded.Folder),
    GALLERY("Galeria", "Gallery", Icons.Rounded.PhotoLibrary),
    EDITOR("Edytor", "Editor", Icons.Rounded.Code),
    VAULT("Sejf", "Vault", Icons.Rounded.Lock),
    SETTINGS("Ustawienia", "Settings", Icons.Rounded.Settings)
}

private fun tr(english: Boolean, pl: String, en: String): String = if (english) en else pl

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun AAAlkoApp(initialUri: Uri?, onBiometric: (() -> Unit, (String) -> Unit) -> Unit) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val prefs = remember { context.getSharedPreferences("aaalko", 0) }
    val vault = remember { VaultManager(context) }
    val lifecycleOwner = LocalLifecycleOwner.current

    var tab by remember { mutableStateOf(AppTab.HOME) }
    var english by remember { mutableStateOf(prefs.getBoolean("english", false)) }
    var treeUri by remember { mutableStateOf(prefs.getString("tree", null)?.let(Uri::parse)) }
    var folderStack by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var fileItems by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var search by remember { mutableStateOf("") }
    var sortMode by remember { mutableStateOf("name") }
    var favouritesOnly by remember { mutableStateOf(false) }
    var favourites by remember { mutableStateOf(prefs.getStringSet("favourites", emptySet())?.toSet() ?: emptySet()) }
    var selectedFiles by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var clipboardFiles by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var clipboardCut by remember { mutableStateOf(false) }
    var showingTrash by remember { mutableStateOf(false) }
    var dialogMode by remember { mutableStateOf("") }
    var dialogName by remember { mutableStateOf("") }
    var dialogTarget by remember { mutableStateOf<DocumentFile?>(null) }
    var deleteTargets by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var detailsTarget by remember { mutableStateOf<DocumentFile?>(null) }
    var toast by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    var albumRoot by remember { mutableStateOf<DocumentFile?>(null) }
    var albums by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }
    var selectedAlbum by remember { mutableStateOf<DocumentFile?>(null) }
    var galleryPhotos by remember { mutableStateOf<List<DocumentFile>>(emptyList()) }

    var editorName by remember { mutableStateOf("Nowy dokument.txt") }
    var editorText by remember { mutableStateOf("") }
    var editorUri by remember { mutableStateOf<Uri?>(null) }
    var editorDirty by remember { mutableStateOf(false) }

    var pinInput by remember { mutableStateOf("") }
    var vaultUnlocked by remember { mutableStateOf(false) }
    var vaultItems by remember { mutableStateOf(vault.items()) }
    var exportItem by remember { mutableStateOf<VaultManager.Item?>(null) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) vaultUnlocked = false
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }
    LaunchedEffect(tab) { if (tab != AppTab.VAULT) vaultUnlocked = false }

    fun rootDoc(): DocumentFile? = treeUri?.let { DocumentFile.fromTreeUri(context, it) }
    fun currentFolder(): DocumentFile? = folderStack.lastOrNull()
    fun notify(message: String) { toast = message }

    LaunchedEffect(initialUri) {
        val incoming = initialUri
        if (incoming != null) {
            runCatching {
                withContext(Dispatchers.IO) {
                    readLimitedText(context, incoming)
                }
            }.onSuccess { content ->
                editorText = content
                editorName = displayName(context, incoming)
                editorUri = incoming
                editorDirty = false
                tab = AppTab.EDITOR
            }.onFailure { toast = tr(english, "Nie udało się otworzyć przekazanego dokumentu.", "Could not open the shared document.") }
        }
    }

    fun refreshFiles() {
        val folder = currentFolder()
        val list = folder?.listFiles()?.toList().orEmpty()
        fileItems = list.sortedWith(
            when (sortMode) {
                "date" -> compareByDescending<DocumentFile> { it.lastModified() }
                "size" -> compareByDescending<DocumentFile> { it.length() }
                "type" -> compareBy<DocumentFile> { it.type.orEmpty() }.thenBy { it.name.orEmpty().lowercase() }
                else -> compareBy<DocumentFile> { !it.isDirectory }.thenBy { it.name.orEmpty().lowercase() }
            }
        )
    }

    fun refreshGallery() {
        val root = rootDoc()
        if (root == null) {
            albumRoot = null; albums = emptyList(); selectedAlbum = null; galleryPhotos = emptyList()
            return
        }
        val dir = root.findFile(AAALKO_ALBUMS)?.takeIf { it.isDirectory } ?: root.createDirectory(AAALKO_ALBUMS)
        albumRoot = dir
        albums = dir?.listFiles()?.filter { it.isDirectory }?.sortedBy { it.name?.lowercase() }.orEmpty()
        val previous = selectedAlbum?.uri?.toString()
        selectedAlbum = albums.firstOrNull { it.uri.toString() == previous } ?: albums.firstOrNull()
        galleryPhotos = selectedAlbum?.listFiles()?.filter { it.isFile && (it.type?.startsWith("image/") == true || it.name.orEmpty().substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "webp", "gif", "heic")) }.orEmpty()
    }

    val treePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
            treeUri = uri
            prefs.edit().putString("tree", uri.toString()).apply()
            val root = DocumentFile.fromTreeUri(context, uri)
            folderStack = listOfNotNull(root)
            showingTrash = false
            refreshFiles(); refreshGallery()
            notify(tr(english, "Lokalizacja została połączona.", "Storage location connected."))
        }
    }
    val openTextPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            runCatching {
                runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION) }
                withContext(Dispatchers.IO) { readLimitedText(context, uri) }
            }.onSuccess { content ->
                editorText = content; editorName = displayName(context, uri); editorUri = uri; editorDirty = false; tab = AppTab.EDITOR
            }.onFailure { notify(tr(english, "Nie udało się otworzyć pliku.", "Could not open the file.")) }
        }
    }
    val saveTextPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/plain")) { uri ->
        if (uri != null) scope.launch {
            runCatching { withContext(Dispatchers.IO) { context.contentResolver.openOutputStream(uri, "w")?.bufferedWriter()?.use { it.write(editorText) } ?: error("Brak dostępu do zapisu") } }
                .onSuccess { editorUri = uri; editorName = displayName(context, uri); editorDirty = false; notify(tr(english, "Dokument zapisany.", "Document saved.")) }
                .onFailure { notify(tr(english, "Nie udało się zapisać dokumentu.", "Could not save the document.")) }
        }
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) {
                runCatching {
                    val root = rootDoc() ?: error("Najpierw wybierz lokalizację plików.")
                    val rootAlbums = root.findFile(AAALKO_ALBUMS) ?: root.createDirectory(AAALKO_ALBUMS) ?: error("Nie można utworzyć folderu albumów.")
                    val target = selectedAlbum ?: rootAlbums.findFile("Importowane") ?: rootAlbums.createDirectory("Importowane") ?: error("Nie można utworzyć albumu.")
                    var copied = 0
                    uris.forEach { uri ->
                        runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
                        val name = uniqueDocumentName(target, displayName(context, uri))
                        val file = target.createFile(context.contentResolver.getType(uri) ?: mimeForName(name), name)
                            ?: error("Nie można utworzyć pliku $name")
                        try {
                            val input = context.contentResolver.openInputStream(uri) ?: error("Nie można odczytać $name")
                            val output = context.contentResolver.openOutputStream(file.uri, "w") ?: error("Nie można zapisać $name")
                            input.use { i -> output.use { o -> i.copyTo(o) } }
                            copied++
                        } catch (error: Exception) {
                            file.delete()
                            throw error
                        }
                    }
                    copied to target
                }
            }
            busy = false
            result.onSuccess { (count, target) -> selectedAlbum = target; notify(tr(english, "Dodano zdjęcia: $count", "Photos imported: $count")); refreshGallery() }
                .onFailure { notify(it.message ?: tr(english, "Import nie powiódł się.", "Import failed.")) }
        }
    }
    val vaultPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) { runCatching { vault.importUri(uri, displayName(context, uri), context.contentResolver.getType(uri)) } }
            busy = false
            result.onSuccess { vaultItems = vault.items(); notify(tr(english, "Plik zaszyfrowano i dodano do sejfu.", "File encrypted and added to vault.")) }
                .onFailure { notify(it.message ?: tr(english, "Nie udało się zaszyfrować pliku.", "Could not encrypt the file.")) }
        }
    }
    val vaultExportPicker = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/octet-stream")) { uri ->
        val item = exportItem
        if (uri != null && item != null) scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) { runCatching { vault.exportTo(item, uri) } }
            busy = false
            result.onSuccess { notify(tr(english, "Plik odszyfrowano i wyeksportowano.", "File decrypted and exported.")) }
                .onFailure { notify(tr(english, "Eksport nie powiódł się. Plik mógł być uszkodzony.", "Export failed. The file may be damaged.")) }
            exportItem = null
        }
    }

    fun openDocument(file: DocumentFile) {
        if (file.isDirectory) {
            folderStack = folderStack + file
            showingTrash = showingTrash || file.name == AAALKO_TRASH
            search = ""; selectedFiles = emptyList(); refreshFiles()
        } else if (isTextDocument(file)) {
            scope.launch {
                busy = true
                val result = withContext(Dispatchers.IO) { runCatching {
                    readLimitedText(context, file.uri)
                } }
                busy = false
                result.onSuccess { editorText = it; editorName = file.name ?: "Dokument.txt"; editorUri = file.uri; editorDirty = false; tab = AppTab.EDITOR }
                    .onFailure { notify(it.message ?: tr(english, "Nie można odczytać pliku.", "Cannot read the file.")) }
            }
        } else {
            runCatching {
                context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(file.uri, file.type ?: "*/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
            }.onFailure { notify(tr(english, "Brak aplikacji do otwarcia tego pliku.", "No app is available to open this file.")) }
        }
    }

    fun toggleFavourite(file: DocumentFile) {
        val key = file.uri.toString()
        favourites = if (key in favourites) favourites - key else favourites + key
        prefs.edit().putStringSet("favourites", favourites).apply()
    }

    fun moveToTrash(file: DocumentFile): Boolean {
        if (showingTrash) {
            val deleted = file.delete()
            if (deleted) {
                val key = "${file.uri}\n"
                val mappings = prefs.getStringSet("trash_restore_map", emptySet())?.toMutableSet() ?: mutableSetOf()
                mappings.removeAll { it.startsWith(key) }
                prefs.edit().putStringSet("trash_restore_map", mappings).apply()
            }
            return deleted
        }
        val root = rootDoc() ?: return false
        val trash = root.findFile(AAALKO_TRASH) ?: root.createDirectory(AAALKO_TRASH) ?: return false
        val copied = copyDocumentTree(context, file, trash) ?: return false
        val relativeParent = folderStack.drop(1).mapNotNull { it.name }.joinToString("\u001F")
        val mapping = "${copied.uri}\n$relativeParent"
        val mappings = prefs.getStringSet("trash_restore_map", emptySet())?.toMutableSet() ?: mutableSetOf()
        mappings.add(mapping)
        prefs.edit().putStringSet("trash_restore_map", mappings).apply()
        return file.delete().also { if (!it) { copied.delete(); mappings.remove(mapping); prefs.edit().putStringSet("trash_restore_map", mappings).apply() } }
    }

    fun restoreFromTrash(file: DocumentFile): Boolean {
        val root = rootDoc() ?: return false
        val mappings = prefs.getStringSet("trash_restore_map", emptySet())?.toMutableSet() ?: mutableSetOf()
        val mapping = mappings.firstOrNull { it.substringBefore('\n') == file.uri.toString() }
        val relativeParent = mapping?.substringAfter('\n', "").orEmpty()
        var destination = root
        if (relativeParent.isNotBlank()) {
            relativeParent.split('\u001F').forEach { segment ->
                val next = destination.findFile(segment)?.takeIf { it.isDirectory }
                if (next != null) destination = next
            }
        }
        val restored = copyDocumentTree(context, file, destination) ?: return false
        val deleted = file.delete()
        if (deleted && mapping != null) {
            mappings.remove(mapping)
            prefs.edit().putStringSet("trash_restore_map", mappings).apply()
        }
        if (!deleted) restored.delete()
        return deleted
    }

    fun pasteClipboard() {
        if (clipboardFiles.isEmpty()) return
        val destination = currentFolder() ?: return
        scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) { runCatching {
                var count = 0
                clipboardFiles.forEach { source ->
                    val copied = copyDocumentTree(context, source, destination) ?: error("Nie udało się skopiować ${source.name}.")
                    if (clipboardCut && !source.delete()) { copied.delete(); error("Skopiowano plik, ale nie udało się usunąć oryginału.") }
                    count++
                }
                count
            } }
            busy = false
            result.onSuccess { clipboardFiles = emptyList(); clipboardCut = false; selectedFiles = emptyList(); refreshFiles(); notify(tr(english, "Przeniesiono/skopiowano elementy: $it", "Items pasted: $it")) }
                .onFailure { refreshFiles(); notify(it.message ?: "Błąd operacji") }
        }
    }

    fun deleteSelected() {
        val targets = deleteTargets.ifEmpty { selectedFiles }
        if (targets.isEmpty()) return
        deleteTargets = emptyList()
        scope.launch {
            busy = true
            val result = withContext(Dispatchers.IO) { runCatching {
                var count = 0
                targets.forEach { file -> if (moveToTrash(file)) count++ else error("Nie udało się usunąć ${file.name}.") }
                count
            } }
            busy = false; deleteTargets = emptyList(); selectedFiles = emptyList(); refreshFiles()
            result.onSuccess { count -> notify(if (showingTrash) tr(english, "Usunięto na stałe: $count", "Permanently deleted: $count") else tr(english, "Przeniesiono do kosza: $count", "Moved to trash: $count")) }
                .onFailure { notify(it.message ?: tr(english, "Operacja nie powiodła się.", "Operation failed.")) }
        }
    }

    BackHandler(enabled = tab != AppTab.HOME || (tab == AppTab.FILES && (folderStack.size > 1 || showingTrash))) {
        when {
            tab == AppTab.FILES && showingTrash -> {
                showingTrash = false
                folderStack = listOfNotNull(rootDoc())
                refreshFiles()
            }
            tab == AppTab.FILES && folderStack.size > 1 -> {
                folderStack = folderStack.dropLast(1)
                refreshFiles()
            }
            tab != AppTab.HOME -> tab = AppTab.HOME
        }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Accent, onPrimary = Color(0xFF07111B), background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White, secondary = Good
    )) {
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF121D2A), Bg, Color.Black)))) {
            Box(Modifier.size(270.dp).offset(x = 175.dp, y = (-95).dp).blur(100.dp).background(Color(0x334D91C8), CircleShape))
            Scaffold(modifier = Modifier.statusBarsPadding(), containerColor = Color.Transparent, bottomBar = {
                GlassBottomBar(tab, english) { next ->
                    tab = next
                    when (next) {
                        AppTab.FILES -> { if (folderStack.isEmpty()) folderStack = listOfNotNull(rootDoc()); refreshFiles() }
                        AppTab.GALLERY -> refreshGallery()
                        AppTab.VAULT -> { vaultItems = vault.items(); if (!vault.hasPin()) vaultUnlocked = false }
                        else -> Unit
                    }
                }
            }) { padding ->
                AnimatedContent(targetState = tab, modifier = Modifier.fillMaxSize().padding(padding), transitionSpec = {
                    (androidx.compose.animation.fadeIn(tween(220)) + androidx.compose.animation.slideInVertically(tween(220)) { it / 24 }) togetherWith
                        androidx.compose.animation.fadeOut(tween(120))
                }, label = "main-tab") { active ->
                    when (active) {
                        AppTab.HOME -> HomeScreen(english, treeUri != null,
                            onFiles = { tab = AppTab.FILES; if (folderStack.isEmpty()) folderStack = listOfNotNull(rootDoc()); refreshFiles() },
                            onGallery = { tab = AppTab.GALLERY; refreshGallery() },
                            onEditor = { tab = AppTab.EDITOR }, onVault = { tab = AppTab.VAULT; vaultItems = vault.items() },
                            onSettings = { tab = AppTab.SETTINGS })
                        AppTab.FILES -> FilesScreen(
                            english = english, files = fileItems, search = search, onSearch = { search = it },
                            folderName = currentFolder()?.name ?: tr(english, "Pamięć urządzenia", "Device storage"),
                            canGoBack = folderStack.size > 1 || showingTrash, showingTrash = showingTrash,
                            selected = selectedFiles, favourites = favourites, favouritesOnly = favouritesOnly,
                            clipboardCount = clipboardFiles.size, clipboardCut = clipboardCut,
                            onChooseRoot = { treePicker.launch(null) },
                            onBack = {
                                if (showingTrash) {
                                    showingTrash = false
                                    folderStack = listOfNotNull(rootDoc())
                                } else if (folderStack.size > 1) {
                                    folderStack = folderStack.dropLast(1)
                                }
                                refreshFiles()
                            },
                            onOpen = ::openDocument,
                            onCreateFolder = { dialogMode = "folder"; dialogName = "" },
                            onCreateFile = { dialogMode = "newfile"; dialogName = "Nowy dokument.txt" },
                            onRename = { file -> dialogTarget = file; dialogMode = "rename"; dialogName = file.name ?: "" },
                            onDelete = { file -> deleteTargets = listOf(file) },
                            onDetails = { detailsTarget = it }, onFavourite = ::toggleFavourite,
                            onRestore = { file -> scope.launch {
                                busy = true
                                val result = withContext(Dispatchers.IO) { runCatching { restoreFromTrash(file) } }
                                busy = false; refreshFiles()
                                result.onSuccess { ok -> notify(if (ok) tr(english, "Element przywrócony.", "Item restored.") else tr(english, "Nie udało się przywrócić elementu.", "Could not restore item.")) }
                                    .onFailure { notify(tr(english, "Przywracanie nie powiodło się.", "Restore failed.")) }
                            } },
                            onCopy = { file -> clipboardFiles = listOf(file); clipboardCut = false; notify(tr(english, "Skopiowano do schowka.", "Added to copy buffer.")) },
                            onCut = { file -> clipboardFiles = listOf(file); clipboardCut = true; notify(tr(english, "Gotowe do przeniesienia.", "Ready to move.")) },
                            onToggleSelect = { file -> selectedFiles = if (file in selectedFiles) selectedFiles - file else selectedFiles + file },
                            onCopySelected = { clipboardFiles = selectedFiles; clipboardCut = false; selectedFiles = emptyList(); notify(tr(english, "Zaznaczone elementy skopiowano.", "Selected items copied.")) },
                            onCutSelected = { clipboardFiles = selectedFiles; clipboardCut = true; selectedFiles = emptyList(); notify(tr(english, "Zaznaczone elementy gotowe do przeniesienia.", "Selected items ready to move.")) },
                            onDeleteSelected = { deleteTargets = selectedFiles }, onPaste = ::pasteClipboard,
                            onSort = { sortMode = it; refreshFiles() }, sortMode = sortMode,
                            onToggleFavourites = { favouritesOnly = !favouritesOnly }, onOpenTrash = {
                                val root = rootDoc()
                                val trash = root?.let { it.findFile(AAALKO_TRASH) ?: it.createDirectory(AAALKO_TRASH) }
                                if (root != null && trash != null) { folderStack = listOf(root, trash); showingTrash = true; refreshFiles() }
                                else notify(tr(english, "Nie udało się otworzyć kosza.", "Could not open trash."))
                            }, onRefresh = ::refreshFiles
                        )
                        AppTab.GALLERY -> GalleryScreen(english, treeUri != null, albums, selectedAlbum, galleryPhotos,
                            onChooseRoot = { treePicker.launch(null) }, onSelectAlbum = { selectedAlbum = it; galleryPhotos = it.listFiles().filter { f -> f.isFile && (f.type?.startsWith("image/") == true || f.name.orEmpty().substringAfterLast('.', "").lowercase() in setOf("jpg", "jpeg", "png", "webp", "gif", "heic")) } },
                            onCreateAlbum = { dialogMode = "album"; dialogName = "" }, onAddPhotos = { photoPicker.launch(arrayOf("image/*")) },
                            onOpenPhoto = { photo -> runCatching { context.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(photo.uri, photo.type ?: "image/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) } }
                        )
                        AppTab.EDITOR -> EditorScreen(english, editorName, editorText, editorDirty,
                            onText = { editorText = it; editorDirty = true }, onOpen = { openTextPicker.launch(arrayOf("text/*", "application/json", "application/xml", "application/javascript")) },
                            onSave = {
                                val uri = editorUri
                                if (uri == null) saveTextPicker.launch(editorName.ifBlank { "Dokument.txt" })
                                else scope.launch {
                                    val result = withContext(Dispatchers.IO) { runCatching { context.contentResolver.openOutputStream(uri, "wt")?.bufferedWriter()?.use { it.write(editorText) } ?: error("Brak dostępu do zapisu") } }
                                    result.onSuccess { editorDirty = false; notify(tr(english, "Zapisano zmiany.", "Changes saved.")) }
                                        .onFailure { notify(tr(english, "Zapis nie powiódł się. Użyj Zapisz jako.", "Save failed. Use Save as.")) }
                                }
                            }, onSaveAs = { saveTextPicker.launch(editorName.ifBlank { "Dokument.txt" }) },
                            onNew = { editorName = "Nowy dokument.txt"; editorText = ""; editorUri = null; editorDirty = false })
                        AppTab.VAULT -> VaultScreen(english, vault.hasPin(), vaultUnlocked, pinInput, vaultItems,
                            onPinInput = { pinInput = it.filter(Char::isDigit).take(12) },
                            onSubmitPin = {
                                val enteredPin = pinInput
                                val creatingPin = !vault.hasPin()
                                scope.launch {
                                    busy = true
                                    val result = withContext(Dispatchers.Default) { runCatching {
                                        if (!vault.hasPin()) { vault.setPin(enteredPin); true } else vault.verifyPin(enteredPin)
                                    } }
                                    busy = false
                                    result.onSuccess { accepted ->
                                        if (accepted) { vaultUnlocked = true; pinInput = ""; vaultItems = vault.items(); if (creatingPin) notify(tr(english, "PIN sejfu ustawiony.", "Vault PIN created.")) }
                                        else { pinInput = ""; notify(tr(english, "Nieprawidłowy PIN.", "Incorrect PIN.")) }
                                    }.onFailure { notify(it.message ?: tr(english, "Nie udało się skonfigurować sejfu.", "Could not configure the vault.")) }
                                }
                            }, onBiometric = { onBiometric({ vaultUnlocked = true; vaultItems = vault.items() }, ::notify) },
                            onImport = { vaultPicker.launch(arrayOf("*/*")) }, onExport = { item -> exportItem = item; vaultExportPicker.launch(item.name) },
                            onDelete = { item -> runCatching { vault.delete(item); vaultItems = vault.items(); notify(tr(english, "Plik usunięty z sejfu.", "Vault file deleted.")) }.onFailure { notify("Błąd usuwania") } },
                            onLock = { vaultUnlocked = false; pinInput = "" })
                        AppTab.SETTINGS -> SettingsScreen(english, treeUri != null, onLanguage = { english = it; prefs.edit().putBoolean("english", it).apply() }, onChooseRoot = { treePicker.launch(null) }, onAbout = { notify("AAAlko 1.1.1 • Android") })
                    }
                }
            }

            if (toast.isNotBlank()) LaunchedEffect(toast) { kotlinx.coroutines.delay(2600); toast = "" }
            AnimatedVisibility(toast.isNotBlank(), Modifier.align(Alignment.TopCenter).padding(top = 42.dp), enter = fadeIn() + slideInVertically(), exit = fadeOut()) {
                GlassCard(Modifier.padding(horizontal = 20.dp)) { Text(toast, Modifier.padding(horizontal = 16.dp, vertical = 12.dp), color = Color.White, fontSize = 13.sp) }
            }
            if (busy) Box(Modifier.fillMaxSize().background(Color(0x55000000)), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Accent) }
        }
    }

    if (dialogMode.isNotBlank()) {
        val isAlbum = dialogMode == "album"
        val title = when (dialogMode) {
            "folder" -> tr(english, "Nowy folder", "New folder")
            "newfile" -> tr(english, "Nowy plik", "New file")
            "album" -> tr(english, "Nowy album", "New album")
            else -> tr(english, "Zmień nazwę", "Rename")
        }
        AlertDialog(
            onDismissRequest = { dialogMode = "" }, containerColor = Color(0xFF171F2A),
            title = { Text(title) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = dialogName, onValueChange = { dialogName = it }, singleLine = true, label = { Text(tr(english, "Nazwa", "Name")) })
                if (isAlbum) Text(tr(english, "Album zostanie zapisany jako folder w AAAlko Albums.", "The album will be stored as a folder in AAAlko Albums."), color = Muted, fontSize = 12.sp)
            } },
            confirmButton = { TextButton(onClick = {
                val name = dialogName.trim()
                if (name.isBlank() || name.contains('/') || name.contains('\\')) { notify(tr(english, "Podaj poprawną nazwę.", "Enter a valid name.")); return@TextButton }
                when (dialogMode) {
                    "folder" -> { val parent = currentFolder(); val made = parent?.createDirectory(name); notify(if (made != null) tr(english, "Folder utworzony.", "Folder created.") else tr(english, "Nie udało się utworzyć folderu.", "Could not create folder.")); refreshFiles() }
                    "newfile" -> { val parent = currentFolder(); val file = parent?.createFile(mimeForName(name), name); notify(if (file != null) tr(english, "Plik utworzony.", "File created.") else tr(english, "Nie udało się utworzyć pliku.", "Could not create file.")); refreshFiles() }
                    "album" -> { val parent = albumRoot; val album = parent?.createDirectory(name); if (album != null) { selectedAlbum = album; refreshGallery(); notify(tr(english, "Album utworzony.", "Album created.")) } else notify(tr(english, "Nie udało się utworzyć albumu.", "Could not create album.")) }
                    "rename" -> { val ok = dialogTarget?.renameTo(name) == true; notify(if (ok) tr(english, "Nazwa zmieniona.", "Name changed.") else tr(english, "Nie udało się zmienić nazwy.", "Could not rename item.")); refreshFiles(); refreshGallery() }
                }
                dialogMode = ""
            }) { Text(tr(english, "Zapisz", "Save"), color = Accent) } },
            dismissButton = { TextButton(onClick = { dialogMode = "" }) { Text(tr(english, "Anuluj", "Cancel"), color = Muted) } }
        )
    }

    if (deleteTargets.isNotEmpty()) {
        AlertDialog(
            onDismissRequest = { deleteTargets = emptyList() }, containerColor = Color(0xFF171F2A),
            title = { Text(if (showingTrash) tr(english, "Usunąć na stałe?", "Delete permanently?") else tr(english, "Przenieść do kosza?", "Move to trash?")) },
            text = { Text(if (showingTrash) tr(english, "Tego działania nie można cofnąć.", "This action cannot be undone.") else tr(english, "Elementy trafią do kosza. Możesz je później przywrócić.", "Items will be moved to the trash. You can restore them later.")) },
            confirmButton = { TextButton(onClick = ::deleteSelected) { Text(if (showingTrash) tr(english, "Usuń na stałe", "Delete permanently") else tr(english, "Przenieś", "Move"), color = Accent) } },
            dismissButton = { TextButton(onClick = { deleteTargets = emptyList() }) { Text(tr(english, "Anuluj", "Cancel"), color = Muted) } }
        )
    }
    detailsTarget?.let { file ->
        AlertDialog(onDismissRequest = { detailsTarget = null }, containerColor = Color(0xFF171F2A),
            title = { Text(file.name ?: tr(english, "Szczegóły", "Details")) },
            text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DetailLine(tr(english, "Typ", "Type"), if (file.isDirectory) tr(english, "Folder", "Folder") else file.type ?: "application/octet-stream")
                DetailLine(tr(english, "Rozmiar", "Size"), if (file.isDirectory) tr(english, "Folder", "Folder") else formatSize(file.length()))
                DetailLine(tr(english, "Zmodyfikowano", "Modified"), SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()).format(Date(file.lastModified())))
                DetailLine("URI", file.uri.toString())
            } }, confirmButton = { TextButton(onClick = { detailsTarget = null }) { Text("OK", color = Accent) } })
    }
}

@Composable
private fun HomeScreen(english: Boolean, connected: Boolean, onFiles: () -> Unit, onGallery: () -> Unit, onEditor: () -> Unit, onVault: () -> Unit, onSettings: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp), verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Spacer(Modifier.height(18.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text("AAAlko", fontSize = 32.sp, fontWeight = FontWeight.Bold, letterSpacing = (-1.4).sp); Text(tr(english, "Twoja przestrzeń. Twoje pliki.", "Your space. Your files."), color = Muted, fontSize = 13.sp) }
            GlassIcon(Icons.Rounded.Settings, tr(english, "Ustawienia", "Settings"), onSettings)
        }
        GlassCard(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(19.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(tr(english, "Witaj w AAAlko", "Welcome to AAAlko"), color = Muted, fontSize = 13.sp)
                Text(tr(english, "Wszystko pod\npełną kontrolą.", "Everything under\nyour control."), fontSize = 28.sp, lineHeight = 32.sp, fontWeight = FontWeight.SemiBold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(7.dp).background(if (connected) Good else Color(0xFFFFC078), CircleShape))
                    Spacer(Modifier.width(8.dp))
                    Text(if (connected) tr(english, "Lokalizacja plików połączona", "Storage location connected") else tr(english, "Wybierz folder, aby rozpocząć", "Choose a folder to get started"), color = Muted, fontSize = 12.sp)
                }
                if (!connected) Button(onClick = onFiles, shape = RoundedCornerShape(14.dp)) { Text(tr(english, "Połącz pamięć", "Connect storage")) }
            }
        }
        Text(tr(english, "SZYBKI DOSTĘP", "QUICK ACCESS"), color = Muted, fontSize = 11.sp, letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeTile(tr(english, "Pliki", "Files"), tr(english, "Przeglądaj, kopiuj i organizuj", "Browse, copy and organize"), Icons.Rounded.Folder, Modifier.weight(1f), onFiles)
            HomeTile(tr(english, "Galeria", "Gallery"), tr(english, "Zdjęcia i własne albumy", "Photos and custom albums"), Icons.Rounded.PhotoLibrary, Modifier.weight(1f), onGallery)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeTile(tr(english, "Edytor", "Editor"), tr(english, "Tekst i pliki kodu", "Text and code files"), Icons.Rounded.Code, Modifier.weight(1f), onEditor)
            HomeTile(tr(english, "Szyfrowany sejf", "Encrypted vault"), tr(english, "Prywatne pliki AES-GCM", "Private AES-GCM files"), Icons.Rounded.Security, Modifier.weight(1f), onVault)
        }
        GlassCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.AutoAwesome, null, tint = Accent, modifier = Modifier.size(25.dp)); Spacer(Modifier.width(12.dp))
            Column { Text("Liquid Glass", fontWeight = FontWeight.SemiBold); Text(tr(english, "Ciemny interfejs, świetlne refleksy i animowane przejścia.", "Dark interface, soft highlights and animated transitions."), color = Muted, fontSize = 12.sp) }
        } }
        Spacer(Modifier.height(10.dp))
    }
}

@Composable
private fun FilesScreen(
    english: Boolean, files: List<DocumentFile>, search: String, onSearch: (String) -> Unit,
    folderName: String, canGoBack: Boolean, showingTrash: Boolean, selected: List<DocumentFile>, favourites: Set<String>, favouritesOnly: Boolean,
    clipboardCount: Int, clipboardCut: Boolean, onChooseRoot: () -> Unit, onBack: () -> Unit, onOpen: (DocumentFile) -> Unit,
    onCreateFolder: () -> Unit, onCreateFile: () -> Unit, onRename: (DocumentFile) -> Unit, onDelete: (DocumentFile) -> Unit,
    onDetails: (DocumentFile) -> Unit, onFavourite: (DocumentFile) -> Unit, onRestore: (DocumentFile) -> Unit, onCopy: (DocumentFile) -> Unit,
    onCut: (DocumentFile) -> Unit, onToggleSelect: (DocumentFile) -> Unit,
    onCopySelected: () -> Unit, onCutSelected: () -> Unit, onDeleteSelected: () -> Unit, onPaste: () -> Unit,
    onSort: (String) -> Unit, sortMode: String, onToggleFavourites: () -> Unit, onOpenTrash: () -> Unit, onRefresh: () -> Unit
) {
    var sortMenu by remember { mutableStateOf(false) }
    val visible = files.filter { file ->
        (file.name.orEmpty().contains(search, true)) && (!favouritesOnly || file.uri.toString() in favourites) &&
            (file.name != AAALKO_TRASH || showingTrash) && (file.name != AAALKO_ALBUMS || showingTrash)
    }
    Column(Modifier.fillMaxSize().padding(horizontal = 17.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            if (canGoBack) GlassIcon(Icons.Rounded.ArrowBack, tr(english, "Wstecz", "Back"), onBack)
            Column(Modifier.weight(1f).padding(start = if (canGoBack) 10.dp else 0.dp)) {
                Text(if (showingTrash) tr(english, "Kosz", "Trash") else tr(english, "Pliki", "Files"), fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(folderName, color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            GlassIcon(Icons.Rounded.Refresh, tr(english, "Odśwież", "Refresh"), onRefresh)
            Spacer(Modifier.width(6.dp))
            Box {
                GlassIcon(Icons.Rounded.Sort, tr(english, "Sortowanie", "Sort")) { sortMenu = true }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    listOf("name" to tr(english, "Nazwa", "Name"), "date" to tr(english, "Data", "Date"), "size" to tr(english, "Rozmiar", "Size"), "type" to tr(english, "Typ", "Type")).forEach { (key, label) ->
                        DropdownMenuItem(text = { Text(label) }, onClick = { sortMenu = false; onSort(key) }, trailingIcon = { if (sortMode == key) Icon(Icons.Rounded.Check, null, tint = Accent) })
                    }
                }
            }
        }
        Spacer(Modifier.height(13.dp))
        OutlinedTextField(value = search, onValueChange = onSearch, modifier = Modifier.fillMaxWidth(), placeholder = { Text(tr(english, "Szukaj plików i folderów", "Search files and folders")) }, leadingIcon = { Icon(Icons.Rounded.Search, null) }, singleLine = true, shape = RoundedCornerShape(17.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = GlassStroke, focusedBorderColor = Accent, unfocusedContainerColor = Glass, focusedContainerColor = Glass))
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp), verticalAlignment = Alignment.CenterVertically) {
            SmallAction(Icons.Rounded.CreateNewFolder, tr(english, "Folder", "Folder"), onCreateFolder)
            SmallAction(Icons.Rounded.NoteAdd, tr(english, "Plik", "File"), onCreateFile)
            SmallAction(Icons.Rounded.DeleteOutline, tr(english, "Kosz", "Trash"), onOpenTrash)
            SmallAction(if (favouritesOnly) Icons.Rounded.Star else Icons.Rounded.StarBorder, tr(english, "Ulubione", "Favourites"), onToggleFavourites, active = favouritesOnly)
        }
        if (selected.isNotEmpty()) {
            Spacer(Modifier.height(8.dp))
            GlassCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${selected.size} ${tr(english, "zazn.", "selected")}", Modifier.weight(1f), color = Accent, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                IconButton(onClick = onCopySelected) { Icon(Icons.Rounded.ContentCopy, tr(english, "Kopiuj", "Copy"), tint = Color.White) }
                IconButton(onClick = onCutSelected) { Icon(Icons.Rounded.ContentCut, tr(english, "Wytnij", "Cut"), tint = Color.White) }
                IconButton(onClick = onDeleteSelected) { Icon(Icons.Rounded.DeleteOutline, tr(english, "Do kosza", "Trash"), tint = Color.White) }
            } }
        }
        if (clipboardCount > 0) {
            Spacer(Modifier.height(7.dp))
            Button(onClick = onPaste, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) {
                Icon(Icons.Rounded.ContentPaste, null); Spacer(Modifier.width(8.dp)); Text(if (clipboardCut) tr(english, "Przenieś tutaj ($clipboardCount)", "Move here ($clipboardCount)") else tr(english, "Wklej tutaj ($clipboardCount)", "Paste here ($clipboardCount)"))
            }
        }
        Spacer(Modifier.height(10.dp))
        if (visible.isEmpty()) {
            Box(Modifier.fillMaxWidth().weight(1f), contentAlignment = Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Icon(if (showingTrash) Icons.Rounded.DeleteOutline else Icons.Rounded.FolderOpen, null, tint = Accent, modifier = Modifier.size(48.dp))
                    Text(if (showingTrash) tr(english, "Kosz jest pusty", "Trash is empty") else tr(english, "Brak elementów", "No items"), fontWeight = FontWeight.SemiBold)
                    Text(if (search.isNotBlank()) tr(english, "Nie znaleziono pasujących plików.", "No matching files found.") else tr(english, "Wybierz lokalizację albo dodaj pierwszy folder.", "Choose a location or create your first folder."), color = Muted, fontSize = 12.sp)
                    if (files.isEmpty()) Button(onClick = onChooseRoot) { Text(tr(english, "Wybierz lokalizację", "Choose location")) }
                }
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(visible, key = { it.uri.toString() }) { file ->
                    FileRow(file, english, file in selected, file.uri.toString() in favourites, showingTrash,
                        onOpen = { onOpen(file) }, onToggleSelect = { onToggleSelect(file) }, onRename = { onRename(file) },
                        onDelete = { onDelete(file) }, onDetails = { onDetails(file) }, onFavourite = { onFavourite(file) },
                        onRestore = { onRestore(file) }, onCopy = { onCopy(file) }, onCut = { onCut(file) })
                }
            }
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FileRow(file: DocumentFile, english: Boolean, selected: Boolean, favourite: Boolean, trash: Boolean,
                    onOpen: () -> Unit, onToggleSelect: () -> Unit, onRename: () -> Unit, onDelete: () -> Unit,
                    onDetails: () -> Unit, onFavourite: () -> Unit, onRestore: () -> Unit, onCopy: () -> Unit, onCut: () -> Unit) {
    var menu by remember { mutableStateOf(false) }
    GlassCard(Modifier.fillMaxWidth().border(if (selected) 1.dp else 0.dp, if (selected) Accent else Color.Transparent, RoundedCornerShape(21.dp)).combinedClickable(onClick = onOpen, onLongClick = onToggleSelect)) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(42.dp).background(Color(0x22B8DFFF), RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) {
                Icon(if (file.isDirectory) Icons.Rounded.Folder else fileIcon(file.name), null, tint = Accent)
            }
            Spacer(Modifier.width(11.dp))
            Column(Modifier.weight(1f)) {
                Text(file.name ?: tr(english, "Bez nazwy", "Unnamed"), fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(if (file.isDirectory) tr(english, "Folder", "Folder") else "${formatSize(file.length())} • ${file.type ?: "File"}", color = Muted, fontSize = 10.sp, maxLines = 1)
            }
            if (favourite) Icon(Icons.Rounded.Star, null, tint = Accent, modifier = Modifier.size(16.dp))
            Box {
                IconButton(onClick = { menu = true }) { Icon(Icons.Rounded.MoreVert, null, tint = Muted) }
                DropdownMenu(menu, { menu = false }) {
                    DropdownMenuItem(text = { Text(tr(english, "Zaznacz", "Select")) }, onClick = { menu = false; onToggleSelect() })
                    DropdownMenuItem(text = { Text(tr(english, "Kopiuj", "Copy")) }, onClick = { menu = false; onCopy() })
                    DropdownMenuItem(text = { Text(tr(english, "Wytnij", "Cut")) }, onClick = { menu = false; onCut() })
                    DropdownMenuItem(text = { Text(if (favourite) tr(english, "Usuń z ulubionych", "Remove favourite") else tr(english, "Dodaj do ulubionych", "Add to favourites")) }, onClick = { menu = false; onFavourite() })
                    if (!trash) DropdownMenuItem(text = { Text(tr(english, "Zmień nazwę", "Rename")) }, onClick = { menu = false; onRename() })
                    DropdownMenuItem(text = { Text(tr(english, "Szczegóły", "Details")) }, onClick = { menu = false; onDetails() })
                    if (trash) DropdownMenuItem(text = { Text(tr(english, "Przywróć", "Restore"), color = Good) }, onClick = { menu = false; onRestore() })
                    DropdownMenuItem(text = { Text(if (trash) tr(english, "Usuń na stałe", "Delete permanently") else tr(english, "Przenieś do kosza", "Move to trash"), color = Color(0xFFFF9A9A)) }, onClick = { menu = false; onDelete() })
                }
            }
        }
    }
}

@Composable
private fun GalleryScreen(english: Boolean, connected: Boolean, albums: List<DocumentFile>, selectedAlbum: DocumentFile?, photos: List<DocumentFile>,
                          onChooseRoot: () -> Unit, onSelectAlbum: (DocumentFile) -> Unit, onCreateAlbum: () -> Unit, onAddPhotos: () -> Unit, onOpenPhoto: (DocumentFile) -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 17.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { Text(tr(english, "Galeria", "Gallery"), fontSize = 28.sp, fontWeight = FontWeight.Bold); Text(tr(english, "Własne albumy i zdjęcia", "Your albums and photos"), color = Muted, fontSize = 12.sp) }
            GlassIcon(Icons.Rounded.CreateNewFolder, tr(english, "Nowy album", "New album"), onCreateAlbum)
        }
        Spacer(Modifier.height(13.dp))
        if (!connected) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Icon(Icons.Rounded.PhotoLibrary, null, tint = Accent, modifier = Modifier.size(52.dp)); Text(tr(english, "Połącz lokalizację plików", "Connect a storage location"), fontWeight = FontWeight.SemiBold); Button(onClick = onChooseRoot) { Text(tr(english, "Wybierz lokalizację", "Choose location")) }
            } }
        } else {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onAddPhotos, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Rounded.AddPhotoAlternate, null); Spacer(Modifier.width(6.dp)); Text(tr(english, "Importuj zdjęcia", "Import photos")) }
                OutlinedButton(onClick = onCreateAlbum, shape = RoundedCornerShape(14.dp)) { Text(tr(english, "Nowy album", "New album")) }
            }
            Spacer(Modifier.height(13.dp))
            Text(tr(english, "ALBUMY", "ALBUMS"), color = Muted, fontSize = 10.sp, letterSpacing = 1.8.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(7.dp))
            if (albums.isEmpty()) Text(tr(english, "Utwórz album, aby uporządkować zdjęcia.", "Create an album to organize your photos."), color = Muted, fontSize = 12.sp)
            else Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                albums.forEach { album ->
                    val active = selectedAlbum?.uri == album.uri
                    Surface(modifier = Modifier.clip(RoundedCornerShape(14.dp)).clickable { onSelectAlbum(album) }, shape = RoundedCornerShape(14.dp), color = if (active) Color(0x333D83B8) else Glass, border = androidx.compose.foundation.BorderStroke(1.dp, if (active) Accent else GlassStroke)) {
                        Row(Modifier.padding(horizontal = 13.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Rounded.Folder, null, tint = Accent, modifier = Modifier.size(17.dp)); Spacer(Modifier.width(7.dp)); Text(album.name ?: "Album", fontSize = 12.sp, maxLines = 1) }
                    }
                }
            }
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                Text(selectedAlbum?.name ?: tr(english, "Zdjęcia", "Photos"), fontWeight = FontWeight.SemiBold)
                Text("${photos.size} ${tr(english, "zdjęć", "photos")}", color = Muted, fontSize = 11.sp)
            }
            Spacer(Modifier.height(9.dp))
            if (photos.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) {
                Icon(Icons.Rounded.Image, null, tint = Accent, modifier = Modifier.size(48.dp)); Text(tr(english, "Ten album jest pusty", "This album is empty"), fontWeight = FontWeight.SemiBold); Text(tr(english, "Importuj zdjęcia — zostaną skopiowane do albumu.", "Import photos — copies will be stored in this album."), color = Muted, fontSize = 12.sp)
            } }
            else LazyVerticalGrid(columns = GridCells.Fixed(3), modifier = Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                gridItems(photos, key = { it.uri.toString() }) { photo ->
                    Surface(modifier = Modifier.clip(RoundedCornerShape(15.dp)).clickable { onOpenPhoto(photo) }, shape = RoundedCornerShape(15.dp), color = Glass, border = androidx.compose.foundation.BorderStroke(1.dp, GlassStroke)) {
                        Column {
                            AsyncImage(model = photo.uri, contentDescription = photo.name, modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp)))
                            Text(photo.name ?: "Photo", Modifier.padding(7.dp), fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun EditorScreen(english: Boolean, name: String, text: String, dirty: Boolean, onText: (String) -> Unit, onOpen: () -> Unit, onSave: () -> Unit, onSaveAs: () -> Unit, onNew: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 17.dp)) {
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) { Text(tr(english, "Edytor", "Editor"), fontSize = 28.sp, fontWeight = FontWeight.Bold); Text(name + if (dirty) " •" else "", color = Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
            GlassIcon(Icons.Rounded.NoteAdd, tr(english, "Nowy", "New"), onNew); Spacer(Modifier.width(5.dp))
            GlassIcon(Icons.Rounded.FolderOpen, tr(english, "Otwórz", "Open"), onOpen); Spacer(Modifier.width(5.dp))
            GlassIcon(Icons.Rounded.Save, tr(english, "Zapisz", "Save"), onSave)
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text(tr(english, "EDYCJA TEKSTU I KODU", "TEXT & CODE EDITOR"), color = Muted, fontSize = 10.sp, letterSpacing = 1.6.sp)
            TextButton(onClick = onSaveAs) { Text(tr(english, "Zapisz jako", "Save as"), color = Accent, fontSize = 11.sp) }
        }
        OutlinedTextField(value = text, onValueChange = onText, modifier = Modifier.fillMaxSize().padding(bottom = 10.dp), placeholder = { Text(tr(english, "Zacznij pisać lub otwórz plik…", "Start typing or open a file…")) }, shape = RoundedCornerShape(19.dp), colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = GlassStroke, focusedBorderColor = Accent, unfocusedContainerColor = Color(0x33111620), focusedContainerColor = Color(0x44111620)), textStyle = androidx.compose.ui.text.TextStyle(fontFamily = FontFamily.Monospace, fontSize = 13.sp, color = Color(0xFFE4EDF7)), minLines = 12)
    }
}

@Composable
private fun VaultScreen(english: Boolean, hasPin: Boolean, unlocked: Boolean, pinInput: String, items: List<VaultManager.Item>, onPinInput: (String) -> Unit,
                        onSubmitPin: () -> Unit, onBiometric: () -> Unit, onImport: () -> Unit, onExport: (VaultManager.Item) -> Unit,
                        onDelete: (VaultManager.Item) -> Unit, onLock: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(14.dp)); Text(tr(english, "Prywatny sejf", "Private vault"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(tr(english, "Szyfrowane pliki chronione kluczem urządzenia", "Files encrypted with a device-keystore key"), color = Muted, fontSize = 11.sp)
        Spacer(Modifier.height(16.dp))
        if (!unlocked) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                GlassCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(13.dp)) {
                    Icon(Icons.Rounded.Shield, null, tint = Accent, modifier = Modifier.size(52.dp))
                    Text(tr(english, "AAAlko Vault", "AAAlko Vault"), fontSize = 22.sp, fontWeight = FontWeight.Bold)
                    Text(if (hasPin) tr(english, "Wpisz PIN, aby odszyfrować listę sejfu.", "Enter your PIN to access the vault.") else tr(english, "Utwórz PIN od 4 do 12 cyfr. Zostanie zapisany jako bezpieczny skrót.", "Create a 4–12 digit PIN. Only a secure hash is stored."), color = Muted, fontSize = 12.sp)
                    OutlinedTextField(value = pinInput, onValueChange = onPinInput, modifier = Modifier.fillMaxWidth(), label = { Text("PIN") }, singleLine = true, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword))
                    Button(onClick = onSubmitPin, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), enabled = pinInput.length >= 4) { Text(if (hasPin) tr(english, "Odblokuj sejf", "Unlock vault") else tr(english, "Ustaw PIN", "Set PIN")) }
                    if (hasPin) OutlinedButton(onClick = onBiometric, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Rounded.Fingerprint, null); Spacer(Modifier.width(8.dp)); Text(tr(english, "Użyj biometrii / blokady telefonu", "Use biometrics / device lock")) }
                    Text(tr(english, "Pliki są szyfrowane AES-256-GCM. PIN nie jest przechowywany w postaci jawnej.", "Files use AES-256-GCM encryption. The PIN is never stored in plain text."), color = Muted, fontSize = 10.sp)
                } }
            }
        } else {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = onImport, modifier = Modifier.weight(1f), shape = RoundedCornerShape(14.dp)) { Icon(Icons.Rounded.Add, null); Spacer(Modifier.width(6.dp)); Text(tr(english, "Dodaj plik", "Add file")) }
                OutlinedButton(onClick = onLock, shape = RoundedCornerShape(14.dp)) { Icon(Icons.Rounded.Lock, null); Spacer(Modifier.width(6.dp)); Text(tr(english, "Zablokuj", "Lock")) }
            }
            Spacer(Modifier.height(13.dp))
            Text("${items.size} ${tr(english, "zaszyfrowanych plików", "encrypted files")}", color = Muted, fontSize = 11.sp)
            Spacer(Modifier.height(8.dp))
            if (items.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(9.dp)) { Icon(Icons.Rounded.Lock, null, tint = Accent, modifier = Modifier.size(48.dp)); Text(tr(english, "Sejf jest pusty", "Your vault is empty"), fontWeight = FontWeight.SemiBold); Text(tr(english, "Dodaj plik, aby zaszyfrować go na urządzeniu.", "Add a file to encrypt it on this device."), color = Muted, fontSize = 12.sp) } }
            else LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp), contentPadding = PaddingValues(bottom = 20.dp)) {
                items(items, key = { it.id }) { item ->
                    GlassCard(Modifier.fillMaxWidth()) { Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Rounded.Lock, null, tint = Accent, modifier = Modifier.size(26.dp)); Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f)) { Text(item.name, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("${formatSize(item.size)} • AES-GCM", color = Muted, fontSize = 10.sp) }
                        IconButton(onClick = { onExport(item) }) { Icon(Icons.Rounded.FileDownload, tr(english, "Eksportuj", "Export"), tint = Color.White) }
                        IconButton(onClick = { onDelete(item) }) { Icon(Icons.Rounded.DeleteOutline, tr(english, "Usuń", "Delete"), tint = Color(0xFFFF9A9A)) }
                    } }
                }
            }
        }
    }
}

@Composable
private fun SettingsScreen(english: Boolean, connected: Boolean, onLanguage: (Boolean) -> Unit, onChooseRoot: () -> Unit, onAbout: () -> Unit) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
        Spacer(Modifier.height(14.dp)); Text(tr(english, "Ustawienia", "Settings"), fontSize = 28.sp, fontWeight = FontWeight.Bold)
        Text(tr(english, "Dostosuj AAAlko do siebie", "Customize your AAAlko experience"), color = Muted, fontSize = 12.sp)
        Spacer(Modifier.height(16.dp))
        SettingsRow(Icons.Rounded.Language, tr(english, "Język aplikacji", "App language"), if (english) "English" else "Polski") {
            onLanguage(!english)
        }
        SettingsRow(Icons.Rounded.Storage, tr(english, "Lokalizacja plików", "File location"), if (connected) tr(english, "Połączona", "Connected") else tr(english, "Nieustawiona", "Not set"), onChooseRoot)
        SettingsRow(Icons.Rounded.Security, tr(english, "Szyfrowany sejf", "Encrypted vault"), "AES-256-GCM")
        SettingsRow(Icons.Rounded.Info, tr(english, "O aplikacji", "About"), "AAAlko 1.1.0", onAbout)
        Spacer(Modifier.height(16.dp))
        GlassCard(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("AAAlko", fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(tr(english, "Menedżer plików z obsługą Storage Access Framework. Aplikacja otrzymuje dostęp wyłącznie do lokalizacji wybranej przez użytkownika.", "File manager built on Android Storage Access Framework. The app only accesses locations explicitly selected by the user."), color = Muted, fontSize = 12.sp, lineHeight = 18.sp)
            Text(tr(english, "Wskazówka: kopia pliku w sejfie jest zaszyfrowana osobnym kluczem Android Keystore. Usunięcie danych aplikacji może uniemożliwić odzyskanie klucza i sejfu.", "Vault files are encrypted with an Android Keystore key. Clearing app data can make the vault key unrecoverable."), color = Muted, fontSize = 11.sp, lineHeight = 16.sp)
        } }
    }
}

@Composable
private fun SettingsRow(icon: ImageVector, title: String, subtitle: String, onClick: (() -> Unit)? = null) {
    val rowModifier = if (onClick != null) Modifier.fillMaxWidth().clickable(onClick = onClick) else Modifier.fillMaxWidth()
    GlassCard(rowModifier) { Row(Modifier.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(23.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(title, fontWeight = FontWeight.Medium); Text(subtitle, color = Muted, fontSize = 11.sp) }; if (onClick != null) Icon(Icons.Rounded.ChevronRight, null, tint = Muted)
    } }
}

@Composable
private fun DetailLine(label: String, value: String) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) { Text(label, color = Muted, fontSize = 10.sp); Text(value, color = Color.White, fontSize = 12.sp) }
}

@Composable
private fun GlassBottomBar(selected: AppTab, english: Boolean, onSelect: (AppTab) -> Unit) {
    Row(Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 10.dp, vertical = 7.dp).clip(RoundedCornerShape(25.dp)).background(Brush.verticalGradient(listOf(Color(0xD5334051), Color(0xE20D121A)))).border(1.dp, Brush.verticalGradient(listOf(Color(0x66FFFFFF), Color(0x12FFFFFF))), RoundedCornerShape(25.dp)).padding(vertical = 7.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
        AppTab.values().forEach { item ->
            val active = selected == item
            val scale by animateFloatAsState(if (active) 1f else .9f, spring(stiffness = Spring.StiffnessMediumLow), label = "nav-${item.name}")
            Column(Modifier.weight(1f).scale(scale).clip(RoundedCornerShape(16.dp)).clickable { onSelect(item) }.background(if (active) Color(0x2EB8DFFF) else Color.Transparent).padding(vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(item.icon, null, tint = if (active) Accent else Muted, modifier = Modifier.size(20.dp))
                Text(if (english) item.en else item.pl, color = if (active) Color.White else Muted, fontSize = 8.sp, fontWeight = if (active) FontWeight.SemiBold else FontWeight.Normal, maxLines = 1)
            }
        }
    }
}

@Composable
private fun HomeTile(title: String, subtitle: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit) {
    GlassCard(modifier.clickable(onClick = onClick)) { Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Icon(icon, null, tint = Accent, modifier = Modifier.size(25.dp)); Text(title, fontWeight = FontWeight.SemiBold); Text(subtitle, color = Muted, fontSize = 10.sp, lineHeight = 14.sp)
    } }
}

@Composable
private fun SmallAction(icon: ImageVector, label: String, onClick: () -> Unit, active: Boolean = false) {
    Surface(modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable(onClick = onClick), shape = RoundedCornerShape(12.dp), color = if (active) Color(0x334B8BB9) else Glass, border = androidx.compose.foundation.BorderStroke(1.dp, if (active) Accent else GlassStroke)) {
        Row(Modifier.padding(horizontal = 9.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically) { Icon(icon, null, tint = Accent, modifier = Modifier.size(15.dp)); Spacer(Modifier.width(5.dp)); Text(label, fontSize = 10.sp, color = Color.White) }
    }
}

@Composable
private fun GlassCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(Brush.linearGradient(listOf(Color(0x32FFFFFF), Color(0x0DFFFFFF), Color(0x1B8CB9E8)))).border(1.dp, Brush.linearGradient(listOf(Color(0x66FFFFFF), Color(0x12FFFFFF), Color(0x30A9D9FF))), RoundedCornerShape(22.dp)), content = content)
}

@Composable
private fun GlassIcon(icon: ImageVector, description: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).clip(CircleShape).background(Glass).border(1.dp, GlassStroke, CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) { Icon(icon, description, tint = Color.White, modifier = Modifier.size(19.dp)) }
}

private fun fileIcon(name: String?): ImageVector = when (name?.substringAfterLast('.', "")?.lowercase()) {
    "jpg", "jpeg", "png", "webp", "gif", "heic" -> Icons.Rounded.Image
    "mp4", "mkv", "mov" -> Icons.Rounded.Movie
    "mp3", "wav", "flac" -> Icons.Rounded.AudioFile
    "zip", "rar", "7z" -> Icons.Rounded.FolderZip
    "kt", "java", "js", "json", "html", "css", "xml", "py" -> Icons.Rounded.Code
    "pdf" -> Icons.Rounded.PictureAsPdf
    else -> Icons.Rounded.InsertDriveFile
}

private fun formatSize(size: Long): String = when {
    size < 1024 -> "$size B"
    size < 1024 * 1024 -> "${DecimalFormat("0.0").format(size / 1024.0)} KB"
    size < 1024L * 1024L * 1024L -> "${DecimalFormat("0.0").format(size / 1024.0 / 1024.0)} MB"
    else -> "${DecimalFormat("0.00").format(size / 1024.0 / 1024.0 / 1024.0)} GB"
}
