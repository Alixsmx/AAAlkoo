package pl.aaalko.app

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.provider.DocumentsContract
import androidx.documentfile.provider.DocumentFile

const val AAALKO_TRASH = ".AAAlko_Trash"
const val AAALKO_ALBUMS = "AAAlko Albums"

fun displayName(context: Context, uri: Uri): String {
    val cursor = runCatching { context.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null) }.getOrNull()
    val queriedName = cursor?.use { if (it.moveToFirst()) it.getString(0) else null }
    return queriedName ?: uri.lastPathSegment?.substringAfterLast('/') ?: "plik"
}


/** Read a text document with a hard limit to avoid loading arbitrarily large files into memory. */
fun readLimitedText(context: Context, uri: Uri, maxBytes: Long = 8L * 1024L * 1024L): String {
    val output = java.io.ByteArrayOutputStream()
    val input = context.contentResolver.openInputStream(uri)
        ?: error("Nie można odczytać wybranego pliku.")
    input.use { stream ->
        val buffer = ByteArray(16 * 1024)
        var total = 0L
        while (true) {
            val count = stream.read(buffer)
            if (count < 0) break
            total += count
            require(total <= maxBytes) { "Plik jest większy niż 8 MB — edytor tekstu go nie otworzy." }
            output.write(buffer, 0, count)
        }
    }
    return output.toByteArray().toString(Charsets.UTF_8)
}

fun mimeForName(name: String): String {
    val ext = name.substringAfterLast('.', "").lowercase()
    return when (ext) {
        "txt", "md", "csv", "log" -> "text/plain"
        "json" -> "application/json"
        "xml" -> "application/xml"
        "html", "htm" -> "text/html"
        "css" -> "text/css"
        "js" -> "application/javascript"
        "kt", "java", "py", "c", "cpp", "h", "toml", "gradle", "properties", "yml", "yaml" -> "text/plain"
        "jpg", "jpeg" -> "image/jpeg"
        "png" -> "image/png"
        "webp" -> "image/webp"
        "gif" -> "image/gif"
        "mp4" -> "video/mp4"
        "mp3" -> "audio/mpeg"
        "pdf" -> "application/pdf"
        else -> "application/octet-stream"
    }
}

fun isTextDocument(file: DocumentFile): Boolean {
    val name = file.name.orEmpty()
    return file.type?.startsWith("text/") == true ||
        name.substringAfterLast('.', "").lowercase() in setOf("txt", "json", "xml", "html", "htm", "css", "js", "kt", "java", "md", "csv", "log", "py", "yml", "yaml", "toml", "gradle", "properties")
}

fun uniqueDocumentName(parent: DocumentFile, original: String): String {
    if (parent.findFile(original) == null) return original
    val base = original.substringBeforeLast('.', original)
    val ext = if (original.contains('.')) ".${original.substringAfterLast('.')}" else ""
    var index = 1
    while (parent.findFile("$base ($index)$ext") != null) index++
    return "$base ($index)$ext"
}

/** Copies a document or a complete directory tree using the Storage Access Framework. */
fun copyDocumentTree(context: Context, source: DocumentFile, destination: DocumentFile): DocumentFile? {
    if (source.isDirectory) {
        val sourceId = runCatching { DocumentsContract.getDocumentId(source.uri) }.getOrNull()
        val destinationId = runCatching { DocumentsContract.getDocumentId(destination.uri) }.getOrNull()
        if (sourceId != null && destinationId != null && (destinationId == sourceId || destinationId.startsWith("$sourceId/"))) return null
    }
    val name = uniqueDocumentName(destination, source.name ?: "Element")
    if (source.isDirectory) {
        val folder = destination.createDirectory(name) ?: return null
        for (child in source.listFiles()) {
            if (copyDocumentTree(context, child, folder) == null) {
                folder.delete()
                return null
            }
        }
        return folder
    }
    val target = destination.createFile(source.type ?: mimeForName(name), name) ?: return null
    return try {
        val input = context.contentResolver.openInputStream(source.uri)
        val output = context.contentResolver.openOutputStream(target.uri, "w")
        if (input == null || output == null) {
            input?.close(); output?.close(); target.delete(); null
        } else {
            input.use { inputStream -> output.use { outputStream -> inputStream.copyTo(outputStream) } }
            target
        }
    } catch (_: Exception) {
        target.delete()
        null
    }
}
