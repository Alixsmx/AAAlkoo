package pl.aaalko.app

import android.content.Context
import android.net.Uri
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import android.util.Base64
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.DataInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.security.KeyStore
import java.security.SecureRandom
import javax.crypto.Cipher
import javax.crypto.CipherInputStream
import javax.crypto.CipherOutputStream
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.GCMParameterSpec
import javax.crypto.spec.PBEKeySpec

/** Encrypted local vault. File contents are encrypted with an Android Keystore AES-GCM key. */
class VaultManager(private val context: Context) {
    private val prefs = context.getSharedPreferences("aaalko_vault", Context.MODE_PRIVATE)
    private val vaultDir = File(context.filesDir, "vault").apply { mkdirs() }
    private val alias = "pl.aaalko.vault.aes.v1"

    data class Item(
        val id: String,
        val name: String,
        val mime: String,
        val size: Long
    )

    fun hasPin(): Boolean = !prefs.getString("pin_hash", null).isNullOrBlank()

    fun setPin(pin: String) {
        require(pin.length in 4..12 && pin.all(Char::isDigit)) { "PIN musi mieć od 4 do 12 cyfr." }
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        getOrCreateKey()
        prefs.edit()
            .putString("pin_salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("pin_hash", derivePin(pin, salt))
            .apply()
    }

    fun verifyPin(pin: String): Boolean {
        val saltText = prefs.getString("pin_salt", null) ?: return false
        val expected = prefs.getString("pin_hash", null) ?: return false
        val salt = Base64.decode(saltText, Base64.NO_WRAP)
        return constantTimeEquals(expected, derivePin(pin, salt))
    }

    @Synchronized
    fun importUri(uri: Uri, displayName: String, mimeType: String?): Item {
        val id = java.util.UUID.randomUUID().toString()
        val target = File(vaultDir, "$id.aav")
        try {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding")
            cipher.init(Cipher.ENCRYPT_MODE, getOrCreateKey())
            val input = context.contentResolver.openInputStream(uri)
            requireNotNull(input) { "Nie można odczytać wybranego pliku." }
            input.use { source ->
                FileOutputStream(target).use { raw ->
                    raw.write(cipher.iv.size)
                    raw.write(cipher.iv)
                    CipherOutputStream(raw, cipher).use { encrypted -> source.copyTo(encrypted) }
                }
            }
        } catch (error: Exception) {
            target.delete()
            throw error
        }
        val item = Item(id, displayName.ifBlank { "plik" }, mimeType ?: "application/octet-stream", target.length())
        val all = items().toMutableList().apply { add(item) }
        saveItems(all)
        return item
    }

    @Synchronized
    fun items(): List<Item> {
        val json = prefs.getString("items", "[]") ?: "[]"
        val array = runCatching { JSONArray(json) }.getOrElse { JSONArray() }
        return buildList {
            for (i in 0 until array.length()) {
                val obj = array.optJSONObject(i) ?: continue
                val id = obj.optString("id")
                if (id.isBlank() || !File(vaultDir, "$id.aav").exists()) continue
                add(Item(id, obj.optString("name", "plik"), obj.optString("mime", "application/octet-stream"), obj.optLong("size")))
            }
        }
    }

    fun exportTo(item: Item, destination: Uri) {
        val encrypted = File(vaultDir, "${item.id}.aav")
        require(encrypted.isFile) { "Plik sejfu nie istnieje." }

        // First decrypt into a private temporary file. AES-GCM verifies its authentication
        // tag at end-of-stream; only after that succeeds do we write to the chosen URI.
        val temporary = File.createTempFile("aaalko-export-", ".tmp", context.cacheDir)
        try {
            FileInputStream(encrypted).use { raw ->
                val data = DataInputStream(BufferedInputStream(raw))
                val ivLength = data.readUnsignedByte()
                require(ivLength in 12..16) { "Nieprawidłowy plik sejfu." }
                val iv = ByteArray(ivLength)
                data.readFully(iv)
                val cipher = Cipher.getInstance("AES/GCM/NoPadding")
                cipher.init(Cipher.DECRYPT_MODE, getOrCreateKey(), GCMParameterSpec(128, iv))
                CipherInputStream(data, cipher).use { decrypted ->
                    FileOutputStream(temporary).use { tempOutput -> decrypted.copyTo(tempOutput) }
                }
            }

            val output = context.contentResolver.openOutputStream(destination, "w")
            requireNotNull(output) { "Nie można zapisać wybranego miejsca." }
            output.use { out -> temporary.inputStream().use { input -> input.copyTo(out) } }
        } finally {
            temporary.delete()
        }
    }

    @Synchronized
    fun delete(item: Item) {
        val file = File(vaultDir, "${item.id}.aav")
        check(!file.exists() || file.delete()) { "Nie można usunąć pliku z sejfu." }
        saveItems(items().filterNot { it.id == item.id })
    }

    private fun saveItems(items: List<Item>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().put("id", item.id).put("name", item.name).put("mime", item.mime).put("size", item.size))
        }
        prefs.edit().putString("items", array.toString()).apply()
    }

    private fun getOrCreateKey(): SecretKey {
        val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        val spec = KeyGenParameterSpec.Builder(
            alias,
            KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT
        )
            .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
            .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
            .setKeySize(256)
            .setRandomizedEncryptionRequired(true)
            .build()
        generator.init(spec)
        return generator.generateKey()
    }

    private fun derivePin(pin: String, salt: ByteArray): String {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 150_000, 256)
        val bytes = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        spec.clearPassword()
        return Base64.encodeToString(bytes, Base64.NO_WRAP)
    }

    private fun constantTimeEquals(a: String, b: String): Boolean {
        val left = a.toByteArray(Charsets.UTF_8)
        val right = b.toByteArray(Charsets.UTF_8)
        if (left.size != right.size) return false
        var result = 0
        for (i in left.indices) result = result or (left[i].toInt() xor right[i].toInt())
        return result == 0
    }
}
